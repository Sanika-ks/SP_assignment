#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>

// Calculate the elapsed time in microseconds since program start
long calculate_time_interval(struct timeval start) {
    struct timeval now;
    gettimeofday(&now, NULL);
    long seconds = now.tv_sec - start.tv_sec;
    long microseconds = now.tv_usec - start.tv_usec;
    return (seconds * 1000000) + microseconds;  // Total time in microseconds
}

// Print a message with elapsed time since program start
void print_time_message(const char *message, struct timeval start) {
    long interval = calculate_time_interval(start);
    printf("[%ld μs] %s\n", interval, message);
    fflush(stdout);
}

int main() {
    struct timeval start;
    gettimeofday(&start, NULL);  // Record the start time of the program
    
    pid_t parent_pid, child_pid;
    
    print_time_message("Program started by grandparent.", start);
    
    // Grandparent forks the parent process
    parent_pid = fork();
    if (parent_pid < 0) {
        perror("fork");
        exit(1);
    }
    
    if (parent_pid == 0) {
        // Parent process
        char msg[100];
        sprintf(msg, "Parent created with PID %d", getpid());
        print_time_message(msg, start);
        
        // Parent forks the child process
        child_pid = fork();
        if (child_pid < 0) {
            perror("fork");
            exit(1);
        }

        if (child_pid == 0) {
            // Child process
            sprintf(msg, "Child created with PID %d", getpid());
            print_time_message(msg, start);
            
              

            // Busy polling to detect adoption by init process (PID 1)
            while (1) {
                if (getppid() == 1) {
                    print_time_message("Child has been adopted by init process.", start);        
                    break;
                }
            }

            print_time_message("Child terminating.", start);
            exit(0);  // Child terminates here
        }
        
        // Parent sleeps for 3 seconds after forking the child
        sleep(3);
        print_time_message("Parent terminating.", start);
        exit(0);  // Parent becomes a zombie until grandparent waits
    }
    
    // Grandparent process sleeps for 6 seconds as specified
    sleep(6);
    print_time_message("Grandparent calling wait on parent.", start);

    // Grandparent performs wait on parent
    int status;
    pid_t waited_pid = wait(&status);
    if (waited_pid > 0) {
        char msg[100];
        sprintf(msg, "Grandparent wait() returned for PID %d", waited_pid);
        print_time_message(msg, start);
    }

    print_time_message("Grandparent terminating.", start);

    return 0;
}

